from axes.handlers.proxy import AxesProxyHandler
from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.auth.tokens import default_token_generator
from django.core.mail import send_mail
from django.utils.encoding import force_bytes, force_str
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from rest_framework import status
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.throttling import ScopedRateThrottle
from rest_framework.views import APIView
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
from rest_framework_simplejwt.tokens import RefreshToken

from cart.services import merge_guest_cart

from .auth import (
    ACCESS_COOKIE,
    ACCESS_MAX_AGE,
    REFRESH_COOKIE,
    clear_auth_cookies,
    cookie_kwargs,
    set_auth_cookies,
)
from .serializers import (
    GoogleAuthSerializer,
    LoginSerializer,
    PasswordResetConfirmSerializer,
    PasswordResetRequestSerializer,
    RegisterSerializer,
    UserSerializer,
)

User = get_user_model()


class LoginThrottle(ScopedRateThrottle):
    scope = "login"


class RegisterThrottle(ScopedRateThrottle):
    scope = "register"


class ResetThrottle(ScopedRateThrottle):
    scope = "reset"


class RegisterView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [RegisterThrottle]

    def post(self, request):
        s = RegisterSerializer(data=request.data, context={"request": request})
        s.is_valid(raise_exception=True)
        user = s.save()
        merge_guest_cart(request, user)
        resp = Response(UserSerializer(user).data, status=status.HTTP_201_CREATED)
        return set_auth_cookies(resp, user, remember=False)


class LoginView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [LoginThrottle]

    def post(self, request):
        # If django-axes has locked this IP/username, refuse early.
        if not AxesProxyHandler.is_allowed(request):
            return Response(
                {"detail": "Too many failed attempts. Try again later."},
                status=status.HTTP_429_TOO_MANY_REQUESTS,
            )
        s = LoginSerializer(data=request.data, context={"request": request})
        s.is_valid(raise_exception=True)
        user = s.validated_data["user"]
        merge_guest_cart(request, user)
        resp = Response(UserSerializer(user).data)
        return set_auth_cookies(resp, user, remember=s.validated_data["remember"])


class LogoutView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        raw = request.COOKIES.get(REFRESH_COOKIE)
        if raw:
            try:
                RefreshToken(raw).blacklist()
            except (TokenError, InvalidToken):
                pass
        return clear_auth_cookies(Response(status=status.HTTP_204_NO_CONTENT))


class RefreshView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        raw = request.COOKIES.get(REFRESH_COOKIE)
        if not raw:
            return Response({"detail": "No refresh token."}, status=401)
        try:
            refresh = RefreshToken(raw)
        except (TokenError, InvalidToken):
            return clear_auth_cookies(Response({"detail": "Invalid refresh token."}, status=401))
        resp = Response(status=status.HTTP_200_OK)
        resp.set_cookie(ACCESS_COOKIE, str(refresh.access_token), max_age=ACCESS_MAX_AGE, **cookie_kwargs())
        return resp


class MeView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response(UserSerializer(request.user).data)


class GoogleAuthView(APIView):
    """Verify a Google ID token server-side, then issue our own cookies."""
    permission_classes = [AllowAny]

    def post(self, request):
        s = GoogleAuthSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        from google.auth.transport import requests as g_requests
        from google.oauth2 import id_token

        try:
            info = id_token.verify_oauth2_token(
                s.validated_data["credential"],
                g_requests.Request(),
                settings.GOOGLE_CLIENT_ID,
            )
        except ValueError:
            return Response({"detail": "Invalid Google token."}, status=400)

        if not info.get("email_verified"):
            return Response({"detail": "Google email not verified."}, status=400)

        email = info["email"].lower()
        user, created = User.objects.get_or_create(
            email=email,
            defaults={"full_name": info.get("name", ""), "email_verified": True},
        )
        if created:
            user.set_unusable_password()  # they log in via Google, no local password
            user.save(update_fields=["password"])
        merge_guest_cart(request, user)
        resp = Response(UserSerializer(user).data, status=200 if not created else 201)
        return set_auth_cookies(resp, user, remember=True)


class PasswordResetRequestView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [ResetThrottle]

    def post(self, request):
        s = PasswordResetRequestSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        email = s.validated_data["email"].lower().strip()
        user = User.objects.filter(email__iexact=email).first()
        if user and user.has_usable_password():
            uid = urlsafe_base64_encode(force_bytes(user.pk))
            token = default_token_generator.make_token(user)
            link = f"{settings.FRONTEND_URL}/reset-password?uid={uid}&token={token}"
            send_mail(
                "Reset your Zoiko password",
                f"Reset your password: {link}\nThis link expires shortly and can be used once.",
                settings.DEFAULT_FROM_EMAIL, [user.email], fail_silently=True,
            )
        return Response({"detail": "If that email exists, a reset link has been sent."})


class PasswordResetConfirmView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        s = PasswordResetConfirmSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        try:
            uid = force_str(urlsafe_base64_decode(s.validated_data["uid"]))
            user = User.objects.get(pk=uid)
        except (User.DoesNotExist, ValueError, TypeError, OverflowError):
            return Response({"detail": "Invalid reset link."}, status=400)
        if not default_token_generator.check_token(user, s.validated_data["token"]):
            return Response({"detail": "Invalid or expired reset link."}, status=400)
        user.set_password(s.validated_data["password"])
        user.save(update_fields=["password"])
        return Response({"detail": "Password updated."})
